<?php

    $host = $_REQUEST['host'];
    $db_name = $_REQUEST['db_name'];
    $user_name = $_REQUEST['user_name'];
    $db_pass = $_REQUEST['db_pass'];

    $mysqli = mysqli_connect($host,$user_name,$db_pass, $db_name); 
    if (!$mysqli) {
       echo json_encode(array('status' => 'fail'));   
    }
    else{
        echo json_encode(array('status' => 'success')); 
    }


?>